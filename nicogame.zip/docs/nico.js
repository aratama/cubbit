if(window.location.hostname === "html5.nicogame.jp"){
    var link = document.createElement("link");
    link.setAttribute("rel", "stylesheet");
    link.setAttribute("href", "nico.css");
    link.setAttribute("type", "text/css");
    document.head.appendChild(link);
}